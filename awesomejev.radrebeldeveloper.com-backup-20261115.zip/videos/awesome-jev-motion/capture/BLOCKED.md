# Capture Failed

Page extraction timed out while running in-page script (Network.enable timed out. Increase the 'protocolTimeout' setting in launch/connect calls for a higher timeout if needed.). The page likely opened, but a later capture step hung.

URL: https://radrebelsam.github.io/awesome-jev/

## What to try

- Re-run with a longer timeout: `--timeout 60000`
- The site may block headless browsers (anti-bot protection)
- Try capturing a different page on the same domain
