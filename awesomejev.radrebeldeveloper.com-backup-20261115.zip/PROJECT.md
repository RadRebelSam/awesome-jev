---
name: AwesomeJev
slug: awesomejev
type: directory   # content | service | saas | mobile | chrome-extension | plugin | directory | product | misc
kw_tag: kw/directory
status: live   # idea | building | live | paused | killed | archived
para: TODO(ask)   # project = being built or active | area = not active
dba: Rad-Rebel-Developer-DBA
vault_tag: 1-PARA/b-Area/Rad-Rebel-Enterprise-LLC/Rad-Rebel-Developer-DBA/awesomejev
vault_note:
obsidian: false   # true = show this project in Obsidian (tasks, card, board); false = Code only
parent: # slug of the main project when this is a part of it (script, app, site)   # slug of the main project when this is a part of it (script, app, site)
part: # what part this is, for example 'MemoGram filler script'   # what part this is, for example 'MemoGram filler script'
folder: D:\My Drive (dexinyyy@gmail.com)\Code\directory\awesomejev.radrebeldeveloper.com
domain: awesomejev.radrebeldeveloper.com
live_url:
repo: https://github.com/RadRebelSam/awesome-jev
slogan:
created:
updated: 2026-10-11
kill_date:
next_review:
---

# AwesomeJev

> **Slogan:** <one line>
> **One-liner:** <who has what problem, what we sell>

Rules for this file
- It is the encyclopedia of the project. The front matter above is machine-read by the dashboard sync, so keep keys and format exactly.
- Update it the same day anything changes (new account, new email, new URL, step done).
- NEVER store passwords, API keys, tokens, recovery codes or card numbers here. Write where they live instead (password manager entry name, env var name, `.env` path).
- Unknown value: write `TODO(ask)`. Never guess or invent.
- Dates are YYYY-MM-DD. Checklist items stay in the `- [ ]` / `- [x]` format so progress can be counted.
- Do not copy legal or tax identifiers (FEIN, licence numbers, personal addresses) here. They live in the LLC area note in Obsidian.

## 0. Auto-detected facts (2026-10-11, from the folder scan)

Generated when this file was created. Verify, then move what matters into the sections below and delete this block.

- Git: yes; remote: https://github.com/RadRebelSam/awesome-jev; branch: main
- Last commit: 2026-09-29 0ef6493 chore: refresh index (2026-09-29)
- Uncommitted files at scan: 0
- Top-level docs: `CONTRIBUTING.md`, `PROJECT.md`, `README.md`
- Top-level folders: `.claude`, `.github`, `brand`, `data`, `site`, `tools`, `topics`, `videos`
- Brand folder: yes; site or landing: yes; README: yes

## 1. Quick facts

| Item | Value |
|---|---|
| Primary domain | |
| Parent brand / domain | |
| Live URL | |
| Repo and branch | |
| Hosting and how to deploy | |
| DBA / legal entity (name only) | |
| Kill rule | |
| Review dates | day 14: ____  day 30: ____ |

## 2. Where to find what

| What | Where |
|---|---|
| Brief | `brief.md` |
| Owned-tool stack and gaps | `stack.md` |
| Presence plan | `presence-plan.md` |
| Brand kit (logo, favicon, banner, tokens) | `brand\` |
| Site source | `site\` |
| App source | `app\` |
| Social assets and queue | `social\` |
| Demo | `demo\` |
| Workflows | `workflows\` |
| Kanban snapshot | `KANBAN.md` |
| Launch checklist | section 10 below |
| Reviews | `review.md` |
| Obsidian note | `vault_note` in the front matter |
| Other docs | |

## 3. About

- **What it is:**
- **Who it is for:**
- **Problem it solves:**
- **Offer and pricing:**
- **Positioning (why us, versus whom):**
- **Tone of voice:**
- **Competitors and alternatives:**
- **Do not claim / do not invent:** (testimonials, numbers, customers, anything not real)

## 4. Brand

| Item | Value |
|---|---|
| Logo files | `brand\logo\` |
| Favicon set | `brand\favicon\` |
| Accent (light-mode text-safe) | `#______` contrast __:1 |
| Accent (dark-mode bright) | `#______` |
| Other colours | |
| Typeface | |
| Theme | light | dark | both |
| Mark differs from every sibling? | ☐ |
| Brand kit IDs in tools (non-secret) | |

## 5. Emails

One row per address. Say what each is used for so nothing gets registered with the wrong one.

| Address | Purpose | Provider and mailbox | Forwards to | Used to register |
|---|---|---|---|---|
| | public contact (hello@ or contact@) | | | |
| | support | | | |
| | accounts and sign-ups (the one used to register every service) | | | |
| | billing and invoices | | | |
| | system / no-reply sender | | | |
| | DMARC reports | | | |
| | legal / privacy | | | |
| | owner of master accounts | | | |

Sending setup: SPF ☐ DKIM ☐ DMARC ☐ (record location: )

## 6. Accounts registry

Every account, one row. Where the password lives is a name, not the password.

### 6a. Social and community

Platform names match the owner's tracking sheet (Book1.xlsx). Fill the handle without the @. Put phone numbers in the password manager and write only a label here (for example "mintmobile-1"), never the number. A dash or blank handle means "not registered".

| Platform | Type | Handle / slug | Profile URL | Owner (LLC / DBA / Personal) | Login email | Phone label | Scheduler or notes | Status |
|---|---|---|---|---|---|---|---|---|
| LinkedIn profile | profile | | | | | | | |
| LinkedIn page | page | | | | | | | |
| Discord | server | | | | | | | |
| Discord channel | channel | | | | | | | |
| Reddit account | account | | | | | | | |
| Reddit community | community | | | | | | | |
| X / Twitter | account | | | | | | | |
| Threads | account | | | | | | | |
| Bluesky | account | | | | | | | |
| Facebook profile | profile | | | | | | | |
| Facebook group | group | | | | | | | |
| Facebook page | page | | | | | | | |
| Substack | publication | | | | | | | |
| Pinterest | account | | | | | | | |
| Instagram | account | | | | | | | |
| TikTok | account | | | | | | | |
| YouTube + Shorts | channel | | | | | | | |
| 小红书 | account | | | | | | | |
| 微信 | account | | | | | | | |
| 微信公众号 | account | | | | | | | |
| 抖音 | account | | | | | | | |
| 哔哩哔哩 | account | | | | | | | |
| Google Business Profile | listing | | | | | | | |
| Medium | account | | | | | | | |
| Other |  | | | | | | | |

Where the passwords live: <password manager entry names, e.g. "VaultName / ProjectName social">

### 6b. Tools and services

| Service | What for | Login email | Username / workspace / account ID | URL | Plan / owned via | Billing date | Where the credential lives | Status |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

### 6c. Stores, marketplaces and developer accounts

| Store | Listing name | Listing ID / bundle / package ID | Login email | URL | Version live | Review status |
|---|---|---|---|---|---|---|
| | | | | | | |

### 6d. Business tools (email signature, booking, community, payments, backend)

| Category | Tool | Account / login email | Status | Notes |
|---|---|---|---|---|
| Business email | | | | |
| Email signature | | | | |
| Booking | | | | |
| Community | | | | |
| Payment gateway: Stripe | | | | |
| Payment gateway: Creem | | | | |
| Payment gateway: Gumroad | | | | |
| Backend / database | | | | |
| Error monitoring (APM) | | | | |
| Other | | | | |

## 7. Domains, DNS and hosting

| Domain / subdomain | Registrar | Points to | Record type | SSL | Renews |
|---|---|---|---|---|---|
| | | | | | |

- Hosting: provider, plan, account email
- Deploy steps (exact):
- Branch and CI:
- Backups:

## 8. Integrations and tracking IDs (non-secret)

| Integration | ID / key name | Where it is set | Verified firing? |
|---|---|---|---|
| Analytics site ID | | | ☐ |
| Heatmap / session tool | | | ☐ |
| Ad pixels | | | ☐ |
| Consent banner | | | ☐ |
| Webhooks | | | ☐ |
| Search Console / Bing | | | ☐ |

## 9. Owned-tool stack in use

Short list of tools actually in use and their role. Full reasoning is in `stack.md`.

| Tool | Role | Configured? |
|---|---|---|
| | | ☐ |

## 10. Checklist

Tick with a date and a link or note. Steps match the launch SOP. Delete rows that do not apply to this type, do not leave them unticked.

### Step 0 to 3: plan and brand
- [ ] Brief written, type chosen, kill rule set
- [ ] DBA and Obsidian note assigned (front matter filled)
- [ ] Owned-tool stack checked (`stack.md`)
- [ ] Presence plan approved
- [ ] Domain bought / DNS plan decided
- [ ] Social handles reserved
- [ ] Logo mark picked, favicon cut made
- [ ] Contrast measured and recorded
- [ ] Banner, avatar, OG image made

### Step 4: site
- [ ] Copy and user journey
- [ ] UI built from brand tokens
- [ ] SEO basics (titles, meta, sitemap, schema, OG)
- [ ] Terms, privacy, cookie consent live
- [ ] Analytics and pixels firing after consent
- [ ] Chatbot and forms wired
- [ ] DNS changed and site deployed
- [ ] Post-deploy checks passed (links, mobile, speed, indexing requested)

### Step 5: core delivery
- [ ] Git repo with a remote (backup) and a `.gitignore` that covers secrets
- [ ] One full end-to-end test run done
- [ ] Security scan done (software types) / quality check done (other types)

### Step 6: social
- [ ] Accounts created (section 6a filled in)
- [ ] Bios and links consistent
- [ ] Connected to scheduler
- [ ] First 3 posts queued

### Step 7: demo and proof
- [ ] Demo built and linked from the site

### Step 8: workflows
- [ ] Marketing cadence written
- [ ] Intake flow tested with a dummy lead
- [ ] Support flow tested
- [ ] Weekly numbers digest set up
- [ ] Billing / renewals set up

### Step 9 to 10: launch and review
- [ ] Launch gate passed
- [ ] Day 14 review done
- [ ] Day 30 review done and decision logged (kill / iterate / scale)

### Step 11: sleep or archive (only when the project stops)
- [ ] `status` and `para` updated in front matter
- [ ] Obsidian note moved from a-Project to b-Area
- [ ] Recurring costs cancelled or noted, domain renewal decision made
- [ ] Final backup and repo archived

### Other items for this project
- [ ]

## 11. Decisions log

| Date | Decision | Why |
|---|---|---|
| | | |

## 12. History

| Date | What changed |
|---|---|
| | |

## 13. Open questions and to-dos

Concrete tasks live in `KANBAN.md` (synced with Obsidian). Keep only questions for the owner here.

-

## 14. Tech and runbook

| Item | Value |
|---|---|
| Stack (language, framework, DB, hosting) | |
| Run locally | `` |
| Build | `` |
| Test | `` |
| Deploy | `` |
| Environment variable NAMES and where the values live | |
| Git state (remote? branch? uncommitted changes?) | |
| Backups (what, where, how often) | |
| Agent instructions file | `AGENTS.md` / `CLAUDE.md` |
| Third-party code and licences | |

## 15. Money

| Item | Value |
|---|---|
| Monthly running cost (tools, hosting, domains, subscriptions) | |
| One-time costs so far | |
| Pricing and plans | |
| Revenue to date | |
| Unit economics (price, cost, margin) | |
| Payment processor and account | |
| Tax and invoicing notes | |

## 16. Metrics (update at every review)

| Metric | Day 0 | Day 14 | Day 30 | Now |
|---|---|---|---|---|
| Visitors | | | | |
| Signups / leads | | | | |
| Customers | | | | |
| Revenue | | | | |
| The one number the kill rule watches | | | | |

## 17. Type appendix (keep only the block for this type)

**content:** channels and handles, content pillars, cadence, production pipeline, repurposing rules, episode or post index, sponsors and monetisation, sources and rights.

**service:** packages and prices, scope and exclusions, delivery SOP, contract and invoice templates, intake form, CRM pipeline stages, current clients and status, vendor dependencies, SLAs.

**saas:** environments (dev, staging, prod), database and migrations, auth provider, billing plan IDs, status page, error monitoring, backups and restore test, data retention, admin access, support inbox, changelog location.

**mobile:** bundle ID, Apple and Google developer accounts, App Store Connect and Play Console IDs, TestFlight state, version and build, privacy labels, screenshots and review notes, push and analytics keys (names only), minimum OS.

**chrome-extension:** Web Store listing ID and URL, version live, permissions and why each is needed, privacy policy URL, licence key and payment system, release zip location, store review state, linked landing page.

**plugin:** host platform, marketplace listing, supported versions, packaging steps, licence, update channel.

**directory:** data sources and refresh schedule, schema, submission and moderation rules, ranking logic, monetisation (listings, ads, affiliate), SEO templates, index size.

**product (physical):** supplier and contact, SKUs and variants, MOQ and lead time, samples status, landed cost (COGS, shipping, duties), price and margin, sales channels and listings (Shopify, Etsy, Amazon, other), inventory and fulfilment, returns and warranty policy, product photos and mockups, compliance and safety labels.

**misc:** what it is for, who uses it, how to run it.

## 18. Risks and dependencies

| Risk or dependency | Impact | Mitigation |
|---|---|---|
| Vendor-hosted engine, platform policy, single point of failure | | |

## 19. Related projects

Parent, children and siblings (shared assets, shared accounts, shared audience).

-

## 20. Obsidian and Kanban

- Obsidian note: see `vault_note` in the front matter (tasks live there, tagged with `vault_tag`).
- `KANBAN.md` in this folder is the synced board snapshot. Edit cards in Obsidian, not here, unless sync says otherwise.
- Dashboard: `D:\My Drive (dexinyyy@gmail.com)\Code\dashboard\` (generated from every project's front matter and checklist).
