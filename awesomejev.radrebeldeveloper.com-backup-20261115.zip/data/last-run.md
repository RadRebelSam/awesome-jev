Automated crawl of GitHub search and the npm registry.

**41 new on the list · 138 new in the review queue · 771 waiting in total**

### Added to the list

- [OmniJev/awesome-jev-gallery](https://github.com/OmniJev/awesome-jev-gallery) — 🔥🔥 Papers, open reproductions and independent evaluations behind System One models and Jev. _(score 28.8, 71 stars)_
- [RadRebelSam/awesome-jev](https://github.com/RadRebelSam/awesome-jev) — A crawler-maintained directory of projects built on Jev, TypeSafe AI's System One model. Daily GitHub + npm sweep, human-merged. _(score 22, 0 stars)_
- [nickthompson480/typesafe-ai-playground](https://github.com/nickthompson480/typesafe-ai-playground) — Community TypeSafe AI playground: 110 use cases, games, dilemmas and model challenges, with editable prompts, A/B comparisons and a mobile-friendly UI. _(score 15.5, 3 stars)_
- [aabolfazl/typesafe-local](https://github.com/aabolfazl/typesafe-local) — Inspired by TypeSafe Ai, Ask a local LLM typed questions, get calibrated probabilities instead of text. Structured output without generation or parsing. MLX / Apple Silicon. _(score 15.2, 6 stars)_
- [Ray-Hughes/jevalyn](https://github.com/Ray-Hughes/jevalyn) — The decision layer for your Rails app. A Rails-native wrapper around TypeSafe's Jev System One API: typed, calibrated decisions in your control flow. _(score 14.9, 4 stars)_
- [y0usaf/typesafe-cli](https://github.com/y0usaf/typesafe-cli) — Ask Jev typed questions from the shell: noul, choice, and score answers as numbers, not prose _(score 14.4, 4 stars)_
- [24601/Augustus](https://github.com/24601/Augustus) — Agent skill: design judgment-assisted systems with TypeSafe Jev (System One). Maps Choice/Score/Noul onto decision theory, reranking, and routing. Composition algebra, question design, validation gates. MIT. _(score 14.2, 3 stars)_
- [AIsa-team/worth-replying](https://github.com/AIsa-team/worth-replying) — Worth Replying by AIsa _(score 14, 3 stars)_
- [reticlehq/reticle](https://github.com/reticlehq/reticle) — AI agents can generate code, but still struggle to understand what they build. Reticle brings Jev-style machine-native runtime perception to web & desktop applications. _(score 13.9, 748 stars)_
- [qkal/Canny](https://github.com/qkal/Canny) — Stops AI coding agents from claiming work is done without evidence. Deterministic hooks decide, TypeSafe's Jev advises. Append-only ledger, zero runtime dependencies. _(score 13.7, 3 stars)_
- [gilljon/typesafe-ai-rs](https://github.com/gilljon/typesafe-ai-rs) — Independent async and blocking Rust SDK for the TypeSafe AI System One API _(score 13.4, 3 stars)_
- [paulsmith/computer-use-jev](https://github.com/paulsmith/computer-use-jev) — macOS computer use driven by Jev (TypeSafe System One) as the decision maker _(score 13.4, 3 stars)_
- [sabeel111/OpenSourceJev](https://github.com/sabeel111/OpenSourceJev) — Turning an LLM model into a Jev like System.  _(score 13.2, 3 stars)_
- [TarunTomar122/jev-askable-arm](https://github.com/TarunTomar122/jev-askable-arm) — Zero-shot English goals on a sim Franka. Jev chains hardcoded primitives. _(score 13.1, 4 stars)_
- [EugeneBoondock/jevsql](https://github.com/EugeneBoondock/jevsql) — SQL with natural-language predicates, powered by TypeSafe's Jev. Filter, rank, classify and score rows by meaning — batched, cached and cost-guarded. _(score 12.7, 3 stars)_
- [InsaneArts/typesafe-sdk-swift](https://github.com/InsaneArts/typesafe-sdk-swift) — Swift SDK for TypeSafe AI _(score 12.7, 3 stars)_
- [sufianetaouil/every](https://github.com/sufianetaouil/every) — Ask a yes/no question of every function in a codebase. Ranked answers in seconds, for cents. Grep whose pattern is a question, powered by TypeSafe Jev. _(score 12.5, 3 stars)_
- [hotchpotch/jev-reranker](https://github.com/hotchpotch/jev-reranker) — Jev-powered relevance filtering and reranking for RAG in Python. _(score 12.4, 3 stars)_
- [genai-craft/openvons](https://github.com/genai-craft/openvons) — openvons (open-Jev): 有限選択肢に確率で答える判断層 — テキスト / 画像 / 日本語音声コマンド _(score 12.2, 9 stars)_
- [deep-diver/mini-jev](https://github.com/deep-diver/mini-jev) — no description _(score 11.9, 3 stars)_
- [adhyaay-karnwal/jev-chat](https://github.com/adhyaay-karnwal/jev-chat) — A chatbot from typed Jev decisions: hierarchical speculative decoding over System One probabilities. _(score 11.8, 3 stars)_
- [kitze/skillbox](https://github.com/kitze/skillbox) — Self-hosted, versioned skills library for AI agents. MCP, scoped clients, and optional Jev recommendations. _(score 11.8, 200 stars)_
- [kitze/unclutter](https://github.com/kitze/unclutter) — WXT browser extension: Jev-powered page clutter removal with reusable template rules. _(score 11.8, 136 stars)_
- [ishantanu/jevmetrics](https://github.com/ishantanu/jevmetrics) — no description _(score 11.6, 3 stars)_
- [Micha0827/snapjudge](https://github.com/Micha0827/snapjudge) — Typed decisions (choice / score / yes-no) from local Qwen models on Apple Silicon. Probabilities come straight from the logits, no text generation. TypeSafe-compatible HTTP API, runs on MLX. _(score 11.4, 3 stars)_
- [AbdelStark/heist-one](https://github.com/AbdelStark/heist-one) — Observable browser stealth game: Jev makes typed guard judgments while deterministic code owns the world. _(score 11, 6 stars)_
- [jamesward/zio-typesafe-ai](https://github.com/jamesward/zio-typesafe-ai) — no description _(score 11, 3 stars)_
- [LamplighterPaul/jev-piano](https://github.com/LamplighterPaul/jev-piano) — Jev cannot generate a single note. Given a piano and the right questions, it improvises anyway. _(score 11, 3 stars)_
- [zaferayan/jev-example](https://github.com/zaferayan/jev-example) — no description _(score 10.9, 3 stars)_
- [jevgpt/discord-live-voice-bot](https://github.com/jevgpt/discord-live-voice-bot) — Discord voice bot with real-time speech: listens to a voice channel, talks back, plays its own music with ducking, and runs 53 server tools behind a voice-based owner gate. Falls back to a fully local pipeline (Whisper + Chatterbox) when the API is down. English and Turkish. _(score 10.5, 6 stars)_
- [pumpkinredbean/bside](https://github.com/pumpkinredbean/bside) — no description _(score 10.5, 3 stars)_
- [rohanarun/computer-use-cache](https://github.com/rohanarun/computer-use-cache) — Drop-in OpenAI-compatible cache that replays repeated computer-use and agent workflows at near-zero cost. _(score 10.5, 40 stars)_
- [cyberofficial/dsh-plugin-jev](https://github.com/cyberofficial/dsh-plugin-jev) — no description _(score 10.4, 3 stars)_
- [0x7067/jev-browse](https://github.com/0x7067/jev-browse) — Browser automation with Jev (TypeSafe) as decision model _(score 10.3, 3 stars)_
- [FBddcz/embodied-jev](https://github.com/FBddcz/embodied-jev) — EmbodiedJev: MuJoCo robot decision workbench with MiniCPM5-2B, Jev and compatible model APIs _(score 10.3, 3 stars)_
- [HyunjunJeon/jev-judgment](https://github.com/HyunjunJeon/jev-judgment) — Agent Skill: send closed coding-agent judgments to TypeSafe Jev _(score 10.3, 3 stars)_
- [Nyarlathoteppppp/pi-heed](https://github.com/Nyarlathoteppppp/pi-heed) — Runtime constraints for the pi coding agent: checks every side-effecting tool call against what you said, before it runs. Powered by TypeSafe Jev. _(score 10.3, 3 stars)_
- [jmesplana/excel_ai_insight](https://github.com/jmesplana/excel_ai_insight) — Excel AI Insight is a web application that allows you to upload Excel files and generate insightful analyses using advanced AI models. This tool helps uncover patterns, trends, and actionable insights quickly and efficiently. _(score 10.1, 3 stars)_
- [kyu1204/oh-my-harness](https://github.com/kyu1204/oh-my-harness) — Tame your AI coding agents with natural language. Generate enforced guardrails (CLAUDE.md, hooks, settings) from a single command. _(score 10.1, 16 stars)_
- [zoidsh/tenet](https://github.com/zoidsh/tenet) — The review gate for code that agents write: rules in plain language, judged on every commit _(score 10.1, 4 stars)_
- …and 1 more

### Before merging

- [ ] Scan the new entries above for anything that only mentions Jev rather than building on it
- [ ] Move anything obvious out of `data/review-queue.md` into `approve` or `reject` in `data/manual.json`

